EXAMPLE FIELD RECORDS
=====================

Synthetic shot records written by Refraction Studio (no real site): one P-wave
line and one SH-wave line, 48 geophones at 3 m spacing, seven shot positions
from -36 m to 177 m. Channel 49 of the P records is a reference geophone at the
shot. Each SH position has a left (L) and a right (R) record.

In Refraction Studio: New project > Import > Choose folder...
  P-wave line:  wave type P, records at the same position "Separate".
  SH-wave line: wave type SH, records at the same position "Opposite SH impacts".
